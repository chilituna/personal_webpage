# 42-Exam-Rank-05

Let's share our knowledge of the exam here.

If you have more information, please specify and/or transcribe the subjects further.

Corrections, functional improvements of solutions, and alternative solution approaches are welcome.

An overview of what we know so far:

| Level | Task    | Known subject | Transcribed subject | Solution available  | Solution passed exam |
|-------|---------|---------------|---------------------|---------------------|----------------------|
| 1     | argo    | Yes           | Yes                 | Yes                 | [Level 1/argo/passing_solution](Level%201/argo/passing_solution) |
| 1     | vbc     | Yes           | Yes                 | Yes                 | [Level 1/vbc/solution](Level%201/vbc/solution) |
| 2     | bigint  | Yes           | Yes                 | Yes                 |                      |
| 2     | polyset | Yes           | Yes                 | Yes                 |       [Level 2/polyset/solution](Level%202/polyset/solution)|
| 2     | vect2   | Yes           | Yes                 | Yes                 | [Level 2/vect2/solution](Level%202/vect2/solution) |
| 3     | life    | Yes           | Yes                 | Yes                 | [Level 3/life/solution](Level%203/life/solution) |
| 3     | bsq     | Yes           | Yes                 | Yes                 |                      |


Note: The owner of this repository is no longer maintaining the code; it is now the responsibility of the current users to maintain it.
